# sistema_bancario

### Description. <br>
The package image_processing is used to:<br>
	Processing:<br>
		- Histogram matching<br>
		- Structural similarity<br>
		- Resize image<br>
	Utils:<br>
		- Read image<br>
		- Save image<br>
		- Plot image<br>
		- Plot results<br>
		- Plot histogram<br>

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image_processing
```

## Usage


## Author
Tainá

## License
[MIT](https://choosealicense.com/licenses/mit/)